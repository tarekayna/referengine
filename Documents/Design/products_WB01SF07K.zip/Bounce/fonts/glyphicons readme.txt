THANK YOU FOR PURCHASING GLYPHICONS!

Your payment will help in the development of new icons. If you would like to be among the first ones to hear about all the news, follow @GLYPHICONS on Twitter.

LICENSE (for GLYPHICONS in all file formats):
------------------- 
A buyer is granted unlimited lifetime usage of all icons purchased on GLYPHICONS.com. The icons can be used for both commercial and personal purposes such as any kinds of mobile applications, web sites, web applications as well as for printing, infographics, etc. You do not need an extra license for every new project. The price in PRO version includes all future updates of GLYPHICONS, which means that no additional purchase is required.

If you use the icons as a part of your design in your product it is perfectly fine. Keep in mind, please, that it is not allowed to resell the icons as such, because the icons are the property of the author.

If you use a font as a part of your html theme / application, which you sell to your customers, it's ok. Bear in mind that reselling of the icons is prohibited and the license is non transferable. Please, be aware that in case you would like to use a font in your html theme / application you should include this license as a part of your product. If your customers would like to use GLYPHICONS as a part of their own (another) product, they have to buy their own license.

GLYPHICONS Halflings are also a part of Bootstrap by Twitter, and are released under the same Apache 2.0 license as Bootstrap. While you are not required to include attribution on your Bootstrap-based projects, I’d certainly appreciate a visibile link back to GLYPHICONS.com in any place you find appropriate (footer, docs, etc).

All logos and trademarks in social icons are the property of the respective trademark owners.®

CONTACT:
-------------------
Web: http://glyphicons.com/
Email: glyphicons@gmail.com
Twitter: http://twitter.com/glyphicons

NOTE:
------------------- 
You don't have to indicate the name of the author, but it always makes me happy when I see a link or a nice tweet about GLYPHICONS :) If you use the icons in your application, website or anywherelse and if you want to, email me please and I will mention about it on Twitter, eventually publish your application on www.glyphicons.com.

Jan Kovařík

